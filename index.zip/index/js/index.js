const text = "aqui você vai encontrar os melhores aplicativo mods para usu no dia a dia aplicativos gratis para intalar no  smart phone"
const speed = 100
let index = 0;

 function typeWriter() {
  if(index < text.length) {
    document.getElementById("nevlek-p")
    innerHTML += text.charAt(index)
    index++
    setTimeout(typeWriter, speed)
  }
}
typeWriter();